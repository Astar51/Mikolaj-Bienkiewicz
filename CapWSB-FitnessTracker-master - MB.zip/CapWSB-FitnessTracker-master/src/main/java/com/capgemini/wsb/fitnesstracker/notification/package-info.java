@NonNullByDefault
package com.capgemini.wsb.fitnesstracker.notification;

import org.eclipse.jdt.annotation.NonNullByDefault;